use warnings;
$email="$ARGV[0]";
use File::Copy;
use Win32;
my $username = Win32::LoginName;
use Archive::Tar;
use Archive::Zip;
use Archive::Zip::Tree;
use File::Path;
print "$email\n";
mkdir "C:/Users/$username/Desktop/server/quadrine/$email" or $error = $!;
unless (-d "C:/Users/$username/Desktop/server/quadrine/$email") {
    die "Cannot create directory C:/Users/$username/Desktop/server/quadrine/$email: $error";
}
print("C:/Users/$username/Desktop/server/dmalano/$email"."_1\n");
copy("C:/Users/$username/Desktop/server/dmalano/$email"."_1","C:/Users/$username/Desktop/server/quadrine/$email/");
print("2");
copy("C:/Users/$username/Desktop/server/dmalano/README.TXT","C:/Users/$username/Desktop/server/quadrine/$email/");
print("3");
copy("C:/Users/$username/Desktop/server/dmalano/$email"."_2","C:/Users/$username/Desktop/server/quadrine/$email/");
print("4");
copy("C:/Users/$username/Desktop/server/dmalano/$email"."_clean.txt","C:/Users/$username/Desktop/server/quadrine/$email/");
unlink "C:/Users/$username/Desktop/server/dmalano/$email"."_clean.txt";
print("5");
copy("C:/Users/$username/Desktop/server/dmalano/$email"."_positive_matrix1.txt","C:/Users/$username/Desktop/server/quadrine/$email/");
unlink "C:/Users/$username/Desktop/server/dmalano/$email"."_positive_matrix1.txt";
print("6");
copy("C:/Users/$username/Desktop/server/dmalano/$email"."_protein_list.txt","C:/Users/$username/Desktop/server/quadrine/$email/");
unlink "C:/Users/$username/Desktop/server/dmalano/$email"."_protein_list.txt";
print("7");
copy("C:/Users/$username/Desktop/server/dmalano/$email"."_WHOLE_MATRIX.csv","C:/Users/$username/Desktop/server/quadrine/$email/");
unlink "C:/Users/$username/Desktop/server/dmalano/$email"."_WHOLE_MATRIX.csv";
print("8");
copy("C:/Users/$username/Desktop/server/dmalano/main_output.txt","C:/Users/$username/Desktop/server/quadrine/$email/");
unlink "C:/Users/$username/Desktop/server/dmalano/main_output.txt";
print("9");
copy("C:/Users/$username/Documents/R/win-library/3.1/h2o/extdata/$email".".csv","C:/Users/$username/Desktop/server/quadrine/$email/");
unlink "C:/Users/$username/Documents/R/win-library/3.1/h2o/extdata/$email".".csv";
print("10");
print "C:/Users/$username/Desktop/server/dmalano/$email".".R";

#making Zip file
my $zip = Archive::Zip->new();
$zip->addTree("C:/Users/$username/Desktop/server/quadrine/$email");
$zip->writeToFileNamed("C:/Users/$username/Desktop/server/quadrine/$email.zip");
move("C:/Users/$username/Desktop/server/quadrine/$email.zip","C:/xampp/htdocs/quadrine/$email.zip");
#removing folder after zipping
rmtree("C:/Users/$username/Desktop/server/quadrine/$email");

		
		rmtree ("C:/Users/$username/Desktop/server/dmalano/$changed_email"."_1");
		rmtree ("C:/Users/$username/Desktop/server/dmalano/$changed_email"."_2");