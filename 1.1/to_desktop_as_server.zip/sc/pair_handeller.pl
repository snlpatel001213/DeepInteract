# use warnings;
$email="$ARGV[0]";
use Win32;
my $username = Win32::LoginName;
print "<h1>procesing pairs $email</h1>";
open PAIR, "C:/Users/$username/Desktop/server/sc/$email"."_2" or die "cannot open file1";#contain pair of proteins
open MATRIX_ALL, "C:/Users/$username/Desktop/server/sc/$email"."_positive_matrix1.txt" or die "cannot open file2";
open TOTAL, ">C:/Users/$username/Documents/R/win-library/3.1/h2o/extdata/$email".".csv" or die "cannot open file1";
open WHOLE_MATRIX, ">C:/Users/$username/Desktop/server/sc/$email"."_WHOLE_MATRIX.csv" or die "cannot open file1";
open HEADER, "C:/Users/$username/Desktop/server/sc/header.txt" or die "cannot open file1";
######################################################################################################################################################
#coping header
while($header=<HEADER>)
{
	print TOTAL "$header\n";
	print WHOLE_MATRIX "name_of_protein(rows),Domain(cols),$header\n";
}
######################################################################################################################################################
while($pair=<PAIR>)
{
	if($pair =~/(?<protein1>[A-Za-z0-9|_-]*)\s+(?<protein2>[A-Za-z0-9|_-]*)/)
	{
		$protein1=$+{protein1};
		$protein2=$+{protein2};
		chomp($protein1);
		chomp($protein2);
		print "$protein1 &nbsp;&nbsp;&nbsp; $protein2<br>";
		
		
	}
$flag=0;
$without_pro1="";
$without_pro2="";
	while($matrix_line_source=<MATRIX_ALL>)
	{
		@matrix_line=split(/,/,$matrix_line_source);
		# print "@matrix_line";
		chomp(@matrix_line);
		if($matrix_line[0] eq $protein1 && $flag == 0)
		{
			# print"$protein1 first one found\n";
			@matrix_line_first_half=@matrix_line;
			$first_protein_name=$matrix_line_first_half[0];
			for($e=1;$e<=scalar(@matrix_line_first_half);$e++)
			{	
				$without_pro1.="$matrix_line_first_half[$e],";
			}
			$flag=1;
			chomp($without_pro1);
			chop($without_pro1);
			chop($without_pro1);
			seek(MATRIX_ALL,0,0);
		}
		if($matrix_line[0] eq $protein2 && $flag == 1)
		{
			# print "$protein2 second one found\n";
			@matrix_line_second_half=@matrix_line;
			$second_protein_name=$matrix_line_second_half[0];
			for($e=1;$e<=scalar(@matrix_line_second_half);$e++)
			{
				$without_pro2.="$matrix_line_second_half[$e],";
			}
			# print "$first_protein_name,$second_protein_name\n";

			chomp($without_pro2);
			$one="$without_pro1"."$without_pro2";
			$WHOLE_MATRIX="$first_protein_name,$second_protein_name,$without_pro1"."$without_pro2";
			chop($one);
			chop($one);
			chop($one);
			print TOTAL"$one\n";
			print WHOLE_MATRIX"$WHOLE_MATRIX\n";
			$without_pro1="";
			$without_pro2="";
			seek(MATRIX_ALL,0,0);
			last;
		}
		
	}
}