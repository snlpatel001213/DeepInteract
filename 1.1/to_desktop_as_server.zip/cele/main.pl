use warnings; 
use Win32;
my $username = Win32::LoginName;
$email="$ARGV[0]";
$organism="$ARGV[1]";
$organism_server="$organism"."_server";
my $x = shift;
my $cmd_file = "C:/Users/$username/Desktop/server/$organism/"."$email".'.R';
$name="sunil";
open my $OUT_FH, '>', $cmd_file or die "Can not open $cmd_file $!\n";
print $OUT_FH <<"EOF";
name<-"$name"
library(h2o)
library(MASS)
localH2O = h2o.init(nthreads = 4,max_mem_size = "4g")
model = h2o.loadModel(localH2O, "C:/Users/$username/Documents/R/win-library/3.1/h2o/extdata/$organism_server")
print(model)
test = system.file("extdata", "$email.csv", package = "h2o")
print ("<h1>$email.csv taken as input</h1><br>")
test.hex = h2o.importFile(localH2O, path = test)
h2o_yhat_test <- h2o.predict(model, test.hex)
summary(h2o_yhat_test)
print(h2o_yhat_test)
write.matrix(h2o_yhat_test,'C:/Users/$username/Desktop/server/$organism/main_output.txt',sep="\\t")
print("####################################################################");
EOF
close $OUT_FH or die "Can not close $cmd_file $!\n";
print "################################################################Parameter file Generated###################################################################";


