#use warnings;
#this file will filter the raw input by user
#this will be called by deepinteract.pl
use Win32;
my $username = Win32::LoginName;
$filename_to_be_cleaned=$ARGV[0]
open FILE, "$filename_to_be_cleaned" or die "cannot open file ";
open OUT, ">domain_clean.txt" or die "cannot open file ";
while($line=<FILE>)
{
	if($line=~/(?<protein_name>[A-Za-z0-9|_-]*)\s+\d+\s+\d+\s+\d+\s+\d+\s+(?<family>[A-Z0-9.]+)\s+/)
	{
		$protein_name="$+{protein_name}";
		$family="$+{family}";
		if($family=~/(?<initial_portion>[A-Z0-9a-z]+).\d*/)
		{
			$family = "$+{initial_portion}";
		}
		print OUT"$protein_name\t$family\n";
	}
}